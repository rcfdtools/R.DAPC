Reset Revit User Interface Readme

This utility is designed to allow you to easily restore the Revit Interface back to the defaults.

The following Screencast video shows what this utility looks like when running:
https://knowledge.autodesk.com/community/screencast/f79191c6-a4d3-4770-9e99-739cfbc351d3

Instructions:
1. Close Revit.
2. Extract the ZIP file.
2. Open the folder for the version of Revit that you want to reset.
3. Double click on the ResetUI.bat file.
4. Launch Revit and confirm that the user interface has been reset to defaults.

Optional: If you want to restore the interface back to its prior state, run the RestoreUI.bat file.

Additional information:
When the reset utiltiy is run, a backup of the settings is stored in the following location:
C:\Autodesk\DiagnosticData\Backup\UI

If the reset utility is run repeatedly, the older backups will be retained with a timestamp appended to the filenames, but the restore utility will only restore the last settings cleared by the reset utility.