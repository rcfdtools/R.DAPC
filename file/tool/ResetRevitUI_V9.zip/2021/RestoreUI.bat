@Echo OFF

REM Overview:
REM -------------------------------------------------------------------
REM 	Version 1.0
REM 	
REM	This utility is designed to restore the previous User Interface settings after being reset by the ResetUI.bat utility
REM
REM		Steps:
REM		Check if Revit is running
REM		Set Variables
REM		Check if needed folders exist
REM		Alert user to what utility will be doing
REM		Move Backup data to Restore folder
REM		Create Backup of current settings and then delete
REM		Restore Settings
REM		Finished
REM -------------------------------------------------------------------

REM -------------------------------------------------------------------
REM Check if Revit is running
REM -------------------------------------------------------------------

REM Variable to control check for running Revit.exe process
Set CheckRevitRunning=1
SETLOCAL EnableExtensions
set EXE=Revit.exe

 If %CheckRevitRunning%==1 (
	FOR /F %%x IN ('tasklist /NH /FI "IMAGENAME eq %EXE%"') DO IF %%x == %EXE% goto FOUND
	echo Not running
	goto Start
:FOUND
	echo An instance of Revit is currently open.
	Echo .
	Echo Please close all versions of Revit before running this utility.
	Echo .
	Echo Aborting
	Echo .
	Timeout /t 10
	Exit /B
 	)


:Start
REM -------------------------------------------------------------------
REM Set Variables
REM -------------------------------------------------------------------

set /p version=<"version.txt"

IF DEFINED username (
set userInfoFile=userData_%Version%_%username%
) else (
set userInfoFile=userData_%Version%_User
)
set timestamp=%DATE:/=-%_%TIME::=-%
set timestamp=%timestamp: =%

set userInfoFile=%userInfoFile%_%timestamp%

set BackupData=C:\Autodesk\DiagnosticData\Backup\UI_%Version%
set RestoreBackupData=%BackupData%\Restore_%Version%

REM -------------------------------------------------------------------



REM -------------------------------------------------------------------
REM Check if needed folders exist
REM -------------------------------------------------------------------

if not exist C:\Autodesk (
mkdir C:\Autodesk
)

if not exist %BackupData% (
mkdir %BackupData%
)
if not exist %RestoreBackupData% (
mkdir %RestoreBackupData%
)

REM -------------------------------------------------------------------

REM -------------------------------------------------------------------
REM Alert user to what utility will be doing
REM -------------------------------------------------------------------
echo .
echo .
echo .
if exist %BackupData%\UiState.dat (
	if exist %BackupData%\WorkspaceBackup.reg (
	REM Both backup items found
	) ELSE (
	REM UIState.dat found but Registry backup not found
	)
	) ELSE (
	REM Neither backup of Revit settings found, batch file will abort
	echo No backup of Revit User Interface settings found
	echo .
	echo Aborting
	echo .
	Timeout /t 10
	Exit
)
echo This utility will restore the Revit User Interface settings that were previously reset to defaults using the ResetUI.bat utility.
echo .
echo .
echo Note: A backup of the current settings will be created here:
echo %BackupData%
echo .
echo .
echo .
echo If you want to cancel this operation, hit Ctrl + C now
echo .
echo .
echo .
Timeout /t 10
REM -------------------------------------------------------------------

REM -------------------------------------------------------------------
REM If utility has been run before rename prior backups
REM -------------------------------------------------------------------

if exist %RestoreBackupData%\UiState.dat (
REN "%RestoreBackupData%\UIState.dat" "UIState %timestamp%.dat"
)

if exist %RestoreBackupData%\WorkspaceBackup.reg (
REN "%RestoreBackupData%\WorkspaceBackup.reg" "WorkspaceBackup %timestamp%.reg"
)

if exist %RestoreBackupData%\RevitUILayout.xml (
REN "%RestoreBackupData%\RevitUILayout.xml" "RevitUILayout %timestamp%.xml"
)

REM -------------------------------------------------------------------


REM -------------------------------------------------------------------
REM Move Backup data to Restore folder
REM -------------------------------------------------------------------

if exist %BackupData%\UiState.dat (
MOVE "%BackupData%\UIState.dat" "%RestoreBackupData%"
)

if exist "%BackupData%\WorkspaceBackup.reg" (
MOVE "%BackupData%\WorkspaceBackup.reg" "%RestoreBackupData%"
)

if exist "%BackupData%\RevitUILayout.xml" (
MOVE "%BackupData%\RevitUILayout.xml" "%RestoreBackupData%"
)

REM -------------------------------------------------------------------


REM -------------------------------------------------------------------
REM Create Backup of current settings and then delete
REM -------------------------------------------------------------------


if exist "%APPDATA%\Autodesk\Revit\Autodesk Revit %Version%\ENU\UIState.dat" (
COPY "%APPDATA%\Autodesk\Revit\Autodesk Revit %Version%\ENU\UIState.dat" %BackupData%\UIState.dat
DEL "%APPDATA%\Autodesk\Revit\Autodesk Revit %Version%\ENU\UIState.dat"
)

if exist %APPDATA%\Autodesk\Revit\Autodesk Revit %Version%\RevitUILayout.xml (
copy "%APPDATA%\Autodesk\Revit\Autodesk Revit %Version%\RevitUILayout.xml" %BackupData%\RevitUILayout.xml
DEL "%APPDATA%\Autodesk\Revit\Autodesk Revit %Version%\RevitUILayout.xml"
)

REG QUERY "HKEY_CURRENT_USER\Software\Autodesk\Revit\Autodesk Revit %version%\Workspace"
IF %errorlevel%==0 (
REM echo Workspace Registry key exists and will be backed up
Timeout /t 10
REG EXPORT "HKEY_CURRENT_USER\Software\Autodesk\Revit\Autodesk Revit %version%\Workspace" "%BackupData%\WorkspaceBackup.reg"
REG DELETE "HKEY_CURRENT_USER\Software\Autodesk\Revit\Autodesk Revit %version%\Workspace" /va /f
) ELSE (
REM echo No Registry Key found
REM Timeout /t 10
)

REM -------------------------------------------------------------------

REM -------------------------------------------------------------------
REM Restore Settings
REM -------------------------------------------------------------------

REM Echo .
REM Echo Restoring UiState.dat
if exist %RestoreBackupData%\UIState.dat (
COPY %RestoreBackupData%\UIState.dat "%APPDATA%\Autodesk\Revit\Autodesk Revit %Version%\ENU\UIState.dat"
)

if exist %RestoreBackupData%\RevitUILayout.xml (
COPY %RestoreBackupData%\RevitUILayout.xml "%APPDATA%\Autodesk\Revit\Autodesk Revit %Version%\RevitUILayout.xml"
)

REG IMPORT %RestoreBackupData%\WorkspaceBackup.reg >>Nul

REM -------------------------------------------------------------------




REM -------------------------------------------------------------------
REM Finished
REM -------------------------------------------------------------------