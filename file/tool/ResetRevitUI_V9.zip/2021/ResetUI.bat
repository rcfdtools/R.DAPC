@Echo OFF

REM Overview:
REM -------------------------------------------------------------------
REM 	Version 1.0
REM
REM		Overview:
REM		Check if Revit is running
REM		Set Variables
REM		Alert user to what utility will be doing
REM		Check if backup folders exist
REM		If utility has been run before rename prior backups
REM		Backup and then Delete UIState.dat
REM		Backup and then Delete Workspace registry key
REM		Done
REM -------------------------------------------------------------------

REM -------------------------------------------------------------------
REM Check if Revit is running
REM -------------------------------------------------------------------

REM Variable to control check for running Revit.exe process
Set CheckRevitRunning=1
SETLOCAL EnableExtensions
set EXE=Revit.exe

 If %CheckRevitRunning%==1 (
	FOR /F %%x IN ('tasklist /NH /FI "IMAGENAME eq %EXE%"') DO IF %%x == %EXE% goto FOUND
	echo Not running
	goto Start
:FOUND
	echo An instance of Revit is currently open.
	Echo .
	Echo Please close all versions of Revit before running this utility.
	Echo .
	Echo Aborting
	Echo .
	Timeout /t 10
	Exit /B
 	)


:Start
REM -------------------------------------------------------------------
REM Set Variables
REM -------------------------------------------------------------------

REM set Version=XXXX
set /p version=<"version.txt"

IF DEFINED username (
set userInfoFile=userData_%Version%_%username%
) else (
set userInfoFile=userData_%Version%_User
)
set timestamp=%DATE:/=-%_%TIME::=-%
REM set timestamp=%timestamp: =%

set userInfoFile=%userInfoFile%_%timestamp%

set BackupData=C:\Autodesk\DiagnosticData\Backup\UI_%Version%

REM -------------------------------------------------------------------

REM -------------------------------------------------------------------
REM Alert user to what utility will be doing
REM -------------------------------------------------------------------

echo .
echo .
echo .
echo .
echo .
echo .
echo .
echo This utility will backup the UIState.dat file and Workspace registry key or RevitUILayout.xml for 2019 and later versions to the following folder:
echo %BackupData%
echo .
echo .
echo .
echo If you want to cancel this operation, hit Ctrl + C now
echo .
echo .
echo .
Timeout /t 10

REM -------------------------------------------------------------------

REM -------------------------------------------------------------------
REM Check if backup folders exist
REM -------------------------------------------------------------------

if not exist C:\Autodesk (
mkdir C:\Autodesk
)

if not exist %BackupData% (
mkdir %BackupData%
)

REM -------------------------------------------------------------------

REM -------------------------------------------------------------------
REM If utility has been run before rename prior backups
REM -------------------------------------------------------------------

if exist %BackupData%\UiState.dat (
REN %BackupData%\UIState.dat "UIState %timestamp%.dat"
)

if exist %BackupData%\WorkspaceBackup.reg (
REN "%BackupData%\WorkspaceBackup.reg" "WorkspaceBackup %timestamp%.reg"
)

if exist %BackupData%\RevitUILayout.xml (
REN "%BackupData%\RevitUILayout.xml" "RevitUILayout %timestamp%.xml"
)

REM -------------------------------------------------------------------

REM -------------------------------------------------------------------
REM Backup and then Delete UIState.dat
REM -------------------------------------------------------------------

copy "%APPDATA%\Autodesk\Revit\Autodesk Revit %Version%\ENU\UIState.dat" %BackupData%\UIState.dat
if exist %BackupData%\UiState.dat (
DEL "%APPDATA%\Autodesk\Revit\Autodesk Revit %Version%\ENU\UIState.dat"
) ELSE (
echo .
echo Failed to reset/backup UIState.dat
echo .
)

REM -------------------------------------------------------------------

REM -------------------------------------------------------------------
REM Backup and then Delete Workspace registry key
REM -------------------------------------------------------------------

REG EXPORT "HKEY_CURRENT_USER\Software\Autodesk\Revit\Autodesk Revit %version%\Workspace" "%BackupData%\WorkspaceBackup.reg"
if exist %BackupData%\WorkspaceBackup.reg (
REG DELETE "HKEY_CURRENT_USER\Software\Autodesk\Revit\Autodesk Revit %version%\Workspace" /f
) ELSE (
REM echo .
REM echo Failed to reset/backup Workspace Registry Key
REM echo .
)

REM -------------------------------------------------------------------

REM -------------------------------------------------------------------
REM Backup and then Delete RevitUILayout.xml
REM -------------------------------------------------------------------

copy "%APPDATA%\Autodesk\Revit\Autodesk Revit %Version%\RevitUILayout.xml" %BackupData%\RevitUILayout.xml
if exist %BackupData%\RevitUILayout.xml (
DEL "%APPDATA%\Autodesk\Revit\Autodesk Revit %Version%\RevitUILayout.xml"
) ELSE (
echo .
echo Failed to reset/backup RevitUILayout.xml
echo .
)

REM -------------------------------------------------------------------

REM -------------------------------------------------------------------
REM Done
REM -------------------------------------------------------------------